### Fusion Emissive Ores 1.0.2
- Account for 1.21.9 pack.mcmeta format changes

### Fusion Emissive Ores 1.0.1
- Fixed breaking overlay being layered multiple times for emissive ores

### Fusion Emissive Ores 1.0.0
- Initial release of Fusion Emissive Ores
